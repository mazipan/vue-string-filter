import { VueConstructor } from "vue";
declare class VueStringFilter implements VueStringFilter {
    install(Vue: VueConstructor): void;
}
declare const _default: VueStringFilter;
export default _default;
